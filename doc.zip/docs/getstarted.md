RE3HDC platform 

System Requirements:<br>
Vivado 2022.2<br>
Python 3.10<br>
Conda / Miniconda (recommended)<br>

Setup steps:<br>
1. Create a new conda environment: conda create --name e3hdc python=3.10.12<br>
2. conda activate e3hdc<br>
3. Run: ./setup.sh<br>

The required python packages should now be installed for the environment.

