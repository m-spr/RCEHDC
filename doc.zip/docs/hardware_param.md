To use the RE3HDC accelerator for any problem with any sizes, no extra hardware motification is needed, and it can be done only by a simple top module generic paramiters set as shown in the following.


----> should we have such a thing??? 
----> first namings
In this part, the needded 
