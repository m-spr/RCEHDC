- [M. S. Roodsari et al., “Otfgencoder-hdc: Hardware-efficient encoding
techniques for hyperdimensional computing,” in 2024 Design, Automa-
tion & Test in Europe Conference & Exhibition (DATE). IEEE, 2024,
pp. 1–2](https://ieeexplore.ieee.org/abstract/document/10546523)